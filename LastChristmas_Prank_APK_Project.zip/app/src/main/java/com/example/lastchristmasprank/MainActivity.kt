package com.example.lastchristmasprank

import android.app.Activity
import android.media.MediaPlayer
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(8, 14, 18))
        }

        val title = TextView(this).apply {
            text = "SYSTEM CONSOLE"
            textSize = 26f
            setTextColor(Color.rgb(80, 255, 140))
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val subtitle = TextView(this).apply {
            text = "Diagnostic simulator • CANULAR INOFFENSIF"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        root.addView(subtitle)

        val logScroll = ScrollView(this)
        val log = TextView(this).apply {
            text = "[OK] Initialisation du système…\n[OK] Analyse des fichiers…\n[!] Chargement du module musical…\n\nTout ceci est une simulation."
            textSize = 16f
            setTextColor(Color.rgb(100, 255, 150))
            setPadding(12, 12, 12, 12)
        }
        logScroll.addView(log)
        root.addView(logScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            text = "Prêt. Appuie sur Démarrer pour lancer la blague."
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        root.addView(status)

        startButton = Button(this).apply {
            text = "DÉMARRER LA BLAGUE"
            setOnClickListener {
                stopPlayback()
                val resId = resources.getIdentifier("last_christmas", "raw", packageName)
                if (resId == 0) {
                    status.text = "Ajoute ton fichier audio : app/src/main/res/raw/last_christmas.mp3"
                    log.append("\n[INFO] Fichier audio absent. Aucun son n'a été lancé.")
                } else {
                    player = MediaPlayer.create(this@MainActivity, resId)
                    if (player == null) {
                        status.text = "Impossible de lire le fichier audio."
                    } else {
                        player?.setOnCompletionListener {
                            stopPlayback()
                            status.text = "SURPRISE ! 😂 C'était une blague !"
                        }
                        player?.start()
                        status.text = "Lecture en cours… Utilise Arrêter la musique si besoin."
                        log.append("\n[OK] Module musical activé.")
                    }
                }
            }
        }
        root.addView(startButton, LinearLayout.LayoutParams(-1, -2))

        stopButton = Button(this).apply {
            text = "ARRÊTER LA MUSIQUE"
            setOnClickListener {
                stopPlayback()
                status.text = "Musique arrêtée."
            }
        }
        root.addView(stopButton, LinearLayout.LayoutParams(-1, -2))

        val revealButton = Button(this).apply {
            text = "RÉVÉLER LA BLAGUE"
            setOnClickListener {
                stopPlayback()
                status.text = "SURPRISE ! 😂 Ce n'était qu'une blague."
                log.append("\n\nSURPRISE ! Ce n'était qu'une blague. 🎄")
            }
        }
        root.addView(revealButton, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    private fun stopPlayback() {
        player?.let {
            try {
                if (it.isPlaying) it.stop()
            } catch (_: IllegalStateException) {}
            it.release()
        }
        player = null
    }

    override fun onStop() {
        stopPlayback()
        super.onStop()
    }

    override fun onDestroy() {
        stopPlayback()
        super.onDestroy()
    }
}
