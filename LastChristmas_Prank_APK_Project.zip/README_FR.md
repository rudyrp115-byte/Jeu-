# Last Christmas — canular musical Android

Projet Android natif minimal (Kotlin) à ouvrir dans Android Studio.

## Fonctionnement
- Affiche un faux écran de terminal, clairement fictif.
- Lance `last_christmas.mp3` après le bouton **Démarrer la blague**.
- Bouton **Arrêter la musique** toujours visible.
- Le son s'arrête si l'application est fermée / quittée.
- Pas de démarrage automatique, pas de fonctionnement caché, pas de verrouillage.

## Ajouter la musique
Copie un fichier audio que tu as le droit d'utiliser dans :
`app/src/main/res/raw/last_christmas.mp3`

Crée le dossier `raw` s'il n'existe pas. Le fichier doit s'appeler exactement `last_christmas.mp3`.
La chanson commerciale « Last Christmas » est protégée par le droit d'auteur ; ce projet ne contient donc pas la chanson.

## Compiler
1. Ouvre le dossier du projet dans Android Studio.
2. Laisse Gradle synchroniser.
3. Choisis **Build > Build APK(s)**.
4. L'APK de debug apparaît généralement dans `app/build/outputs/apk/debug/app-debug.apk`.

Prérequis : Android Studio récent avec Android SDK installé et connexion internet pour télécharger Gradle/les dépendances.
